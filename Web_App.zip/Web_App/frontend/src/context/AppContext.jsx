import React, { createContext, useContext, useState } from 'react';
import { MOCK_LISTINGS } from '../data/mockData';
import { loginRequest, registerRequest } from "../api/auth";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [listings, setListings] = useState(MOCK_LISTINGS);

  const login = async (email, password) => {

    const data = await loginRequest(email, password);

    if (data.access_token) {

      localStorage.setItem("token", data.access_token);

      setCurrentUser(data.user);

    } else {
      throw new Error("Login failed");
    }
  };

  const register = async (email, password) => {

    const data = await registerRequest(email, password);

    if (data.access_token) {

      localStorage.setItem("token", data.access_token);

      setCurrentUser(data.user);

    } else {
      throw new Error("Register failed");
    }
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const addListing = (listing) => {
    setListings((prev) => [listing, ...prev]);
  };

  return (
    <AppContext.Provider value={{ currentUser, listings, login, register, logout, addListing }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
